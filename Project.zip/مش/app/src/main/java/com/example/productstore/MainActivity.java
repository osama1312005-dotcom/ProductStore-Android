package com.example.productstore;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ProductAdapter adapter;
    private final List<Product> allProducts = new ArrayList<>();
    private final List<Product> visibleProducts = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.productsRecyclerView);

        // Two columns, scrolling vertically: matches the reference design.
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerView.setHasFixedSize(true);

        loadProducts();
        visibleProducts.addAll(allProducts);
        adapter = new ProductAdapter(visibleProducts);
        recyclerView.setAdapter(adapter);

        EditText searchEditText = findViewById(R.id.searchEditText);
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterProducts(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void loadProducts() {
        int camera = R.drawable.camera_placeholder;
        allProducts.add(new Product("Bitzwolf B-CC1 Camera 1080P Hd Webcame", "US$48.89", camera));
        allProducts.add(new Product("Bitzwolf B-CC1 Camera 1080P Hd Webcame", "US$55.89", camera));
        allProducts.add(new Product("Bitzwolf B-CC1 Camera 1080P Hd Webcame", "US$78.89", camera));
        allProducts.add(new Product("Bitzwolf B-CC1 Camera 1080P Hd Webcame", "US$88.55", camera));
        allProducts.add(new Product("Bitzwolf B-CC1 Camera 1080P Hd Webcame", "US$23.67", camera));
        allProducts.add(new Product("Bitzwolf B-CC1 Camera 1080P Hd Webcame", "US$44.89", camera));
        allProducts.add(new Product("Wireless HD Webcam", "US$39.99", camera));
        allProducts.add(new Product("Mini Security Camera", "US$29.50", camera));
    }

    private void filterProducts(String query) {
        visibleProducts.clear();
        for (Product product : allProducts) {
            if (product.getName().toLowerCase().contains(query.toLowerCase())) {
                visibleProducts.add(product);
            }
        }
        adapter.notifyDataSetChanged();
    }
}
