Product Store - RecyclerView starter project

Open this folder in Android Studio.

Implementation:
- Java
- RecyclerView
- GridLayoutManager(context, 2): two product columns with vertical scrolling
- Product model + ProductAdapter + ViewHolder pattern
- Search field filters products by name

Important:
The camera image is a vector placeholder because the reference screenshot does not provide separate product image files. Replace app/src/main/res/drawable/camera_placeholder.xml with your own product images (for example camera_1.png, camera_2.png) and set each Product imageResId to its matching drawable.

To run:
1. Open the project in Android Studio.
2. Allow Gradle sync.
3. Run the app on an emulator or Android phone.
